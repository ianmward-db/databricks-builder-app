"""OpenAPI core validation module"""
